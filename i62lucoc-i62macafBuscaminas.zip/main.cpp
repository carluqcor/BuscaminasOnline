
#include "buscaminas.hpp"
#include <iostream>
#include <string>

int main(){
	Buscaminas buscaminas;
	buscaminas.buscaminasGame();
}