#!/bin/bash
$(killall -9 clienteB)
$(killall -9 ServidorB)